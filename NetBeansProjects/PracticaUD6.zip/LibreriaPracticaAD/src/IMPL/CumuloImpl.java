package IMPL;

import DAO.CumuloDAO;
import DTO.*;
import java.io.Serializable;

public class CumuloImpl implements CumuloDAO{
    @Override
    public boolean insertarCumulo(Cumulo cum){
        //TODO
        return true;
    }
    @Override
    public boolean eliminarCumulo(Cumulo cum){
        //TODO
        return true;
    }
    @Override
    public boolean modificarCumulo(Cumulo cum){
        //TODO
        return true;
    }
    @Override
    public Cumulo consultarCumulo(Cumulo cum){
        //TODO
        return cum;
    }
}
