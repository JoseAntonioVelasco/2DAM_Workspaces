package IMPL;

import DAO.GalaxiaDAO;
import DTO.*;
import java.io.Serializable;

public class GalaxiaImpl implements GalaxiaDAO {
    @Override
    public boolean insertarGalaxia(Galaxia gal){
        //TODO
        return true;
    }
    @Override
    public boolean eliminaGalaxia(Galaxia gal){
        //TODO
        return true;
    }
    @Override
    public boolean modificarGalaxia(Galaxia gal){
        //TODO
        return true;
    }
    @Override
    public Galaxia consultarGalaxia(Galaxia gal){
        //TODO
        return gal;
    }
}
