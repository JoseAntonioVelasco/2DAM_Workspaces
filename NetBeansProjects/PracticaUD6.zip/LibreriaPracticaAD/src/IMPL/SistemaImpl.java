package IMPL;

import DAO.SistemaDAO;
import DTO.*;
import java.io.Serializable;

public class SistemaImpl implements SistemaDAO {
    @Override
    public boolean insertarSistema(Sistema sis){
        //TODO
        return true;
    }
    @Override
    public boolean eliminarSistema(Sistema sis){
        //TODO
        return true;
    }
    @Override
    public boolean modificarSistema(Sistema sis){
        //TODO
        return true;
    }
    @Override
    public Sistema consultarSistema(Sistema sis) {
        //TODO
        return sis;
    }
}
