#aritmeticasBasicas
def suma(n1,n2):
    resultado = n1+n2
    print("La suma es ",resultado)
    
def resta(n1,n2):
    resultado = n1 - n2
    print("La resta es ",resultado)

