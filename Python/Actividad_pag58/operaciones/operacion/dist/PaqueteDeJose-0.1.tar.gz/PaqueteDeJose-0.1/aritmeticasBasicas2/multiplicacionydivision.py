#aritmeticasBasicas2
def multiplicacion(n1,n2):
    resultado = n1*n2
    print("La multiplicacion es ",resultado)
    
def division(n1,n2):
    resultado = n1/n2
    print("La division es ",resultado)
