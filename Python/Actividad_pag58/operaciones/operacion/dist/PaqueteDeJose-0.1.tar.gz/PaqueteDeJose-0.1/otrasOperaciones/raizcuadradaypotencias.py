#otrasOperaciones

print("otrasop")