# -*- coding: utf-8 -*-
"""
Created on Wed Dec 16 08:35:38 2020

@author: JoseAntonioVelasco
"""

from setuptools import setup

setup(
      name="PaqueteDeJose",
      version="0.1",
      description="Este es un paquete de prueba para SGE",
      author="jose",
      author_email="joseantonio.velasco@sanviatorvalladolid.com",
      packages=["aritmeticasBasicas","aritmeticasBasicas2","otrasOperaciones"]
)