# -*- coding: utf-8 -*-
"""
Created on Thu Dec 10 08:59:44 2020

@author: ADMIN
"""
def suma():
    print("asdasd")