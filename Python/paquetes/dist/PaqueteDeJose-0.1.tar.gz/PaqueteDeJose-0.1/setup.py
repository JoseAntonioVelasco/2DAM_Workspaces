# -*- coding: utf-8 -*-
"""
Created on Thu Dec 10 08:27:27 2020

@author: ADMIN
"""

from setuptools import setup

setup(
      name="PaqueteDeJose",
      version="0.1",
      description="Este es un paquete de prueba para SGE",
      author="jose",
      author_email="joseantonio.velasco@sanviatorvalladolid.com",
      packages=["paquete"]
)